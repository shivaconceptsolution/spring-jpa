package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Registration;
import com.example.repository.*;

@Service
public class RegistrationService {
	   @Autowired
	   RegistrationRespoitory repository;
	   public void userRegistration(Registration r) {
		      repository.save(r);
		   }
	   public boolean userLogin(String username,String password) {
		      Registration reg = repository.findByUsername(username);
		      if (reg != null && password.equals(reg.getPassword())) {
		            return true; // Authentication successful
		        }
		        return false; // Authentication failed
		   }
}
