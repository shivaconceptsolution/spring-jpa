package com.example.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Employee;
import com.example.entity.Registration;
import com.example.service.EmployeeService;
import com.example.service.RegistrationService;

@RestController
@RequestMapping(path = "/user")
public class RegistrationController {
	@Autowired
	   RegistrationService reg;
	   @PostMapping("/register")
	   public void addEmployee(@RequestBody Registration r) {
	      reg.userRegistration(r);
	   }

}
